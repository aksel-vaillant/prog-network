https://gist.github.com/CarlEkerot/2693246

https://heptadecane.medium.com/file-transfer-via-java-sockets-e8d4f30703a5
